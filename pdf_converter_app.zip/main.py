from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.filechooser import FileChooserIconView
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.core.window import Window
from kivy.properties import BooleanProperty, ListProperty
from PIL import Image
import os


class PDFConverter(BoxLayout):
    is_dark_mode = BooleanProperty(False)
    pdf_files = ListProperty([])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = 20
        self.spacing = 20

        self.toggle_btn = Button(
            text="🌙",
            size_hint=(None, None),
            size=(50, 50),
            background_normal='',
            background_color=(0, 0.478, 1, 1),
            color=(1, 1, 1, 1),
            font_size=32,
            pos_hint={'right': 1}
        )
        self.toggle_btn.bind(on_release=self.toggle_dark_mode)

        top_bar = BoxLayout(size_hint_y=None, height=60)
        top_bar.add_widget(Label())
        top_bar.add_widget(self.toggle_btn)
        self.add_widget(top_bar)

        self.pdf_btn = Button(
            text="PDF yaratish",
            size_hint=(None, None),
            size=(200, 60),
            background_normal='',
            background_color=(0, 0.478, 1, 1),
            color=(1, 1, 1, 1),
            font_size=20,
            bold=True,
            pos_hint={'center_x': 0.5}
        )
        self.pdf_btn.bind(on_release=self.open_filechooser)
        self.add_widget(self.pdf_btn)

        self.files_layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.files_layout.bind(minimum_height=self.files_layout.setter('height'))
        self.scroll_view = ScrollView(size_hint=(1, None), size=(Window.width, 250))
        self.scroll_view.add_widget(self.files_layout)
        self.add_widget(self.scroll_view)
        self.files_layout.height = 0

        self.update_ui()

    def toggle_dark_mode(self, instance):
        self.is_dark_mode = not self.is_dark_mode
        self.update_ui()

    def update_ui(self):
        if self.is_dark_mode:
            Window.clearcolor = (0, 0, 0, 1)
            self.pdf_btn.background_color = (0.1, 0.1, 0.1, 1)
            self.pdf_btn.color = (1, 1, 1, 1)
            self.toggle_btn.background_color = (0, 0.3, 0.7, 1)
            self.toggle_btn.text = "☀️"
            self.files_layout.clear_widgets()
            for f in self.pdf_files:
                btn = Button(text=os.path.basename(f),
                             size_hint_y=None,
                             height=40,
                             background_color=(0.1, 0.1, 0.1, 1),
                             color=(1, 1, 1, 1),
                             halign='center')
                self.files_layout.add_widget(btn)
        else:
            Window.clearcolor = (1, 1, 1, 1)
            self.pdf_btn.background_color = (0, 0.478, 1, 1)
            self.pdf_btn.color = (1, 1, 1, 1)
            self.toggle_btn.background_color = (0, 0.478, 1, 1)
            self.toggle_btn.text = "🌙"
            self.files_layout.clear_widgets()
            for f in self.pdf_files:
                btn = Button(text=os.path.basename(f),
                             size_hint_y=None,
                             height=40,
                             background_color=(0, 0.6, 1, 1),
                             color=(1, 1, 1, 1),
                             halign='center')
                self.files_layout.add_widget(btn)
        self.scroll_view.height = 250 if self.pdf_files else 0

    def open_filechooser(self, instance):
        content = FileChooserIconView(filters=['*.png', '*.jpg', '*.jpeg', '*.bmp'])
        popup = Popup(title="Rasm faylini tanlang", content=content, size_hint=(0.9, 0.9))
        content.bind(on_submit=lambda chooser, selection, touch: self.file_selected(selection, popup))
        popup.open()

    def file_selected(self, selection, popup):
        if selection:
            image_path = selection[0]
            popup.dismiss()
            try:
                output_pdf = self.convert_image_to_pdf(image_path)
                self.pdf_files.append(output_pdf)
                self.update_ui()
                self.show_message("Muvaffaqiyat", f"PDF yaratildi:\n{output_pdf}")
            except Exception as e:
                self.show_message("Xato", f"PDF yaratishda xatolik:\n{e}")

    def convert_image_to_pdf(self, image_path):
        output_pdf_path = image_path.rsplit('.', 1)[0] + "_converted.pdf"
        image = Image.open(image_path)
        if image.mode != 'RGB':
            image = image.convert('RGB')
        image.save(output_pdf_path, "PDF", resolution=100.0)
        return output_pdf_path

    def show_message(self, title, message):
        popup = Popup(title=title,
                      content=Label(text=message),
                      size_hint=(0.7, 0.4))
        popup.open()


class PDFApp(App):
    def build(self):
        return PDFConverter()


if __name__ == "__main__":
    PDFApp().run()